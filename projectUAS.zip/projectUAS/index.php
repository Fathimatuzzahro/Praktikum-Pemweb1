<?php
    require 'functions.php';

    if(isset($_POST["registrasi"])) {
        if(registrasi($_POST)>0) {
            echo "
                <script>
                    alert('Registrasi Berhasil!');
                </script>
            ";
        } else{
            echo mysqli_error($conn);
        }
    }
?>

<!doctype html>
<html lang="en" id="home">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>SIAkd</title>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
    <!-- navbar -->
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <!-- dalam button ada data target yang harus sama dengan id menu pada navbarnya -->
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="#home" class="navbar-brand page-scroll">Sistem Informasi Akademik</a>
            </div>

            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="#home">Home</a></li>
                    <li><a href="#registrasi">Registrasi</a></li>
                    <li><a href="#contact">Contact</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- akhir navbar -->

    <!-- jumbotron -->
    <div class="jumbotron text-center">
        <!-- <img src="img/wpp.jpg" class="img-square"> -->
        <!-- <picture>
            <!-- <source media="(min-width: 992px)" srcset="/media/images/camel.jpg">
            <source media="(min-width: 768px)" srcset="/media/images/mouse.jpg"> -->
            <!-- <img src="img/weather.png" class="img-fluid" alt="gambar">
        </picture> -->
        <h1>SELAMAT DATANG, GOOD PERSON</h1>
    </br>
    </br>
        <p>Dashboard | KRS | KHS</P>
    </div>
    <!-- akhir jumbotron -->

    <!-- Registrasi -->
    <div class="registrasi">
        <form method="POST" action="">
            <section class="registrasi" id="registrasi">
                <div class="container mt-5 shadow rounded p-3">
                    <div class="row">
                        <div class="col-sm-12 text-center">
                        <h2 class="text-center font-weight-bold">Form Registrasi</h2>
                        <hr>
                    </div>
                </div>
                    <div class="row">
                        <div class="col-md-4 col-sm-offset-4 form-group">
                            <label for="email">Email</label>
                            <input type="text" name="email" id="email" class="form-control" placeholder="Masukkan Email" required>
                        </div>
                    </div>
                    <br>

                    <div class="row">
                        <div class="col-md-4 col-sm-offset-4 form-group">
                            <label for="password">Password</label>
                            <input type="password" min="8" name="password" id="password" class="form-control" placeholder="Masukkan Password" required>
                        </div>
                    </div>
                    <br>

                    <div class="row">
                        <div class="col-md-4 col-sm-offset-4 form-group">
                            <label for="password2">Konfirmasi Password</label>
                            <input type="password" min="8" name="password2" id="password2" class="form-control" placeholder="Masukkan Konfirmasi Password" required>
                        </div>
                    </div>
                    <br>

                    <div class="row">
                        <div class="col-md-4 col-sm-offset-4 form-group">
                            <label for="level">Status</label>
                            <br>
                            <input type="radio" name="level" id="level" value="Dosen"> Dosen
                            <br>
                            <input type="radio" name="level" id="level" value="Mahasiswa"> Mahasiswa
                        </div>
                    </div>
                    <br>
	                
                <button type="submit" name="registrasi" class="col-sm-offset-4 btn btn-primary">Daftar</button>
                <button type="reset" class="btn btn-danger">Batal</button>
                
                    <div class="row">
                        <div class="col-md-4 col-sm-offset-4 form-group">
                            <br>
                            <h5 class="text-center font-weight-bold">Already have an account? <a href="login.php">Login</a></h2>
                        </div>
                    </div>
                    <br>
            </section>
        </form>
    </div>

    <!-- footer -->
    <footer>
        <div class="container text-center">
            <div class="row">
                <div class="col-sm-12">
                    <p>&copy; Copyright 2021 | Built with <i class="glyphicon glyphicon-heart"></i> by <a href="http://instagram.com/fzahro.09">Empat Sekawan</a>.</p>
                    <!-- copyright bisa diganti dg &copy supaya jadi logo huruf C dibuletin -->
                    <!-- i bukan untuk italic, tp untuk icon -->
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <a href="https://github.com/Fathimatuzzahro" class="image">
                        <img src="img/GitHub-Mark.png" alt="logo github" class="img-circle">
                    </a>
                    <a href="https://facebook.com/fathimatuzzahro.zahro.7" class="image">
                        <img src="img/Facebook_Logo.png" alt="logo facebook" class="img-circle">
                    </a>
                    <a href="https://twitter.com/fzahro032301" class="image">
                        <img src="img/twitter.jpg" alt="logo twitter" class="img-circle">
                    </a>
                </div>
            </div>
        </div>
    </footer>
    <!-- akhir footer -->

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>

    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>

</body>
</html>