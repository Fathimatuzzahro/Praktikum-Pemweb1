<?php
    session_start();

    $_SESSION = array();
    // session_array();
    // session_unset();
    session_destroy();

    header("Location: login.php");
    exit;

?>