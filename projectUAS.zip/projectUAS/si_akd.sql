-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 26, 2021 at 09:01 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.1.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `si_akd`
--

-- --------------------------------------------------------

--
-- Table structure for table `dosen`
--

CREATE TABLE `dosen` (
  `id_dosen` int(3) NOT NULL,
  `nama_dosen` varchar(30) NOT NULL,
  `nip` int(20) NOT NULL,
  `id_user` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dosen`
--

INSERT INTO `dosen` (`id_dosen`, `nama_dosen`, `nip`, `id_user`) VALUES
(1, 'Fiddin', 22801, 24),
(2, 'Budi', 20154, 25),
(3, 'Jamal', 63225, 26),
(4, 'Fendi', 11890, 27),
(5, 'Hartatik', 98272, 28);

-- --------------------------------------------------------

--
-- Table structure for table `fakultas`
--

CREATE TABLE `fakultas` (
  `id_fakultas` int(3) NOT NULL,
  `nama_fakultas` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fakultas`
--

INSERT INTO `fakultas` (`id_fakultas`, `nama_fakultas`) VALUES
(1, 'Sekolah Vokasi');

-- --------------------------------------------------------

--
-- Table structure for table `jurusan`
--

CREATE TABLE `jurusan` (
  `id_jurusan` int(3) NOT NULL,
  `nama_jurusan` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jurusan`
--

INSERT INTO `jurusan` (`id_jurusan`, `nama_jurusan`) VALUES
(1, 'D3 Teknik Informatika');

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `id_mhs` int(3) NOT NULL,
  `nama_mhs` varchar(30) NOT NULL,
  `nim` varchar(10) NOT NULL,
  `kelas` varchar(2) NOT NULL,
  `jurusan` varchar(30) NOT NULL,
  `angkatan` int(4) NOT NULL,
  `id_user` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mahasiswa`
--

INSERT INTO `mahasiswa` (`id_mhs`, `nama_mhs`, `nim`, `kelas`, `jurusan`, `angkatan`, `id_user`) VALUES
(1, 'Devanza', 'V3420027', 'B', 'D3 Teknik Informatika', 2020, 1),
(2, 'Devi', 'V3420028', 'B', 'D3 Teknik Informatika', 2020, 2),
(3, 'Dicky', 'V3420029', 'B', 'D3 Teknik Informatika', 2020, 3),
(4, 'Ditya', 'V3420030', 'B', 'D3 Teknik Informatika', 2020, 4),
(5, 'Fahro', 'V3420031', 'B', 'D3 Teknik Informatika', 2020, 5),
(6, 'Fathimatuzzahro', 'V3420032', 'B', 'D3 Teknik Informatika', 2020, 6),
(7, 'Fathul', 'V3420033', 'B', 'D3 Teknik Informatika', 2020, 7),
(8, 'Fauzi', 'V3420034', 'B', 'D3 Teknik Informatika', 2020, 8),
(9, 'Gustinov', 'V3420036', 'B', 'D3 Teknik Informatika', 2020, 9),
(10, 'Harjuno', 'V3420037', 'B', 'D3 Teknik Informatika', 2020, 10),
(11, 'Hemas', 'V3420038', 'B', 'D3 Teknik Informatika', 2020, 11),
(12, 'Indra', 'V3420040', 'B', 'D3 Teknik Informatika', 2020, 12),
(13, 'Intan', 'V3420041', 'B', 'D3 Teknik Informatika', 2020, 13),
(14, 'Ismaturrofiah', 'V3420042', 'B', 'D3 Teknik Informatika', 2020, 14),
(15, 'Jovian', 'V3420043', 'B', 'D3 Teknik Informatika', 2020, 15),
(16, 'Ksatria', 'V3420045', 'B', 'D3 Teknik Informatika', 2020, 16),
(17, 'Taufiq', 'V3420046', 'B', 'D3 Teknik Informatika', 2020, 17),
(18, 'Marvi', 'V3420047', 'B', 'D3 Teknik Informatika', 2020, 18),
(19, 'Mika', 'V3420048', 'B', 'D3 Teknik Informatika', 2020, 19),
(20, 'Mu\'adz', 'V3420049', 'B', 'D3 Teknik Informatika', 2020, 20),
(21, 'Azhar', 'V3420050', 'B', 'D3 Teknik Informatika', 2020, 21),
(22, 'Raihan', 'V3420050', 'B', 'D3 Teknik Informatika', 2020, 22),
(23, 'Rizqi', 'V3420051', 'B', 'D3 Teknik Informatika', 2020, 23);

-- --------------------------------------------------------

--
-- Table structure for table `matkul`
--

CREATE TABLE `matkul` (
  `id_matkul` int(3) NOT NULL,
  `nama_matkul` varchar(30) NOT NULL,
  `id_dosen` int(3) NOT NULL,
  `id_jurusan` int(3) NOT NULL,
  `id_fakultas` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `matkul`
--

INSERT INTO `matkul` (`id_matkul`, `nama_matkul`, `id_dosen`, `id_jurusan`, `id_fakultas`) VALUES
(1, 'Pemrograman Web', 1, 1, 1),
(2, 'Start-Up dan Technopreneur', 2, 1, 1),
(3, 'Etika Profesi', 3, 1, 1),
(4, 'Aplikasi Komputer dan Internet', 4, 1, 1),
(5, 'Basis Data', 5, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `nilai`
--

CREATE TABLE `nilai` (
  `id_nilai` int(3) NOT NULL,
  `angka_nilai` int(5) NOT NULL,
  `id_matkul` int(3) NOT NULL,
  `id_dosen` int(3) NOT NULL,
  `id_mhs` int(3) NOT NULL,
  `id_jurusan` int(3) NOT NULL,
  `id_fakultas` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(3) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `level` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `email`, `password`, `level`) VALUES
(1, 'devanza@student.uns.ac.id', '123V3420027', 'mahasiswa'),
(2, 'devi@student.uns.ac.id', '123V3420028', 'mahasiswa'),
(3, 'dicky@student.uns.ac.id', '123V3420029', 'mahasiswa'),
(4, 'ditya@student.uns.ac.id', '123V3420030', 'mahasiswa'),
(5, 'fahro@student.uns.ac.id', '123V3420031', 'mahasiswa'),
(6, 'izah@student.uns.ac.id', '123V3420032', 'mahasiswa'),
(7, 'nisa@student.uns.ac.id', '123V3420033', 'mahasiswa'),
(8, 'fauzi@student.uns.ac.id', '123V3420034', 'mahasiswa'),
(9, 'severo@student.uns.ac.id', '123V3420036', 'mahasiswa'),
(10, 'arjun@student.uns.ac.id', '123V3420037', 'mahasiswa'),
(11, 'hemas@student.uns.ac.id', '123V3420038', 'mahasiswa'),
(12, 'indra@student.uns.ac.id', '123V3420040', 'mahasiswa'),
(13, 'intan@student.uns.ac.id', '123V3420041', 'mahasiswa'),
(14, 'isma@student.uns.ac.id', '123V3420042', 'mahasiswa'),
(15, 'jovian@student.uns.ac.id', '123V3420043', 'mahasiswa'),
(16, 'ksatria@student.uns.ac.id', '123V3420045', 'mahasiswa'),
(17, 'taufiq@student.uns.ac.id', '123V3420046', 'mahasiswa'),
(18, 'marvi@student.uns.ac.id', '123V3420047', 'mahasiswa'),
(19, 'mika@student.uns.ac.id', '123V3420048', 'mahasiswa'),
(20, 'muadz@student.uns.ac.id', '123V3420049', 'mahasiswa'),
(21, 'azhar@student.uns.ac.id', '123V3420050', 'mahasiswa'),
(22, 'raihan@student.uns.ac.id', '123V3420051', 'mahasiswa'),
(23, 'rizqi@student.uns.ac.id', '123V3420052', 'mahasiswa'),
(24, 'fiddin@staff.uns.ac.id', 'dosen1', 'dosen'),
(25, 'budi@staff.uns.ac.id', 'dosen2', 'dosen'),
(26, 'jamal@staff.uns.ac.id', 'dosen3', 'dosen'),
(27, 'fendi@staff.uns.ac.id', 'dosen4', 'dosen'),
(28, 'hartatik@staff.uns.ac.id', 'dosen5', 'dosen'),
(29, 'admin@staff.uns.ac.id', 'admin21', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dosen`
--
ALTER TABLE `dosen`
  ADD PRIMARY KEY (`id_dosen`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `fakultas`
--
ALTER TABLE `fakultas`
  ADD PRIMARY KEY (`id_fakultas`);

--
-- Indexes for table `jurusan`
--
ALTER TABLE `jurusan`
  ADD PRIMARY KEY (`id_jurusan`);

--
-- Indexes for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`id_mhs`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `matkul`
--
ALTER TABLE `matkul`
  ADD PRIMARY KEY (`id_matkul`),
  ADD KEY `id_fakultas` (`id_fakultas`),
  ADD KEY `id_jurusan` (`id_jurusan`),
  ADD KEY `id_dosen` (`id_dosen`);

--
-- Indexes for table `nilai`
--
ALTER TABLE `nilai`
  ADD PRIMARY KEY (`id_nilai`),
  ADD KEY `id_mhs` (`id_mhs`),
  ADD KEY `id_fakultas` (`id_fakultas`),
  ADD KEY `id_jurusan` (`id_jurusan`),
  ADD KEY `id_matkul` (`id_matkul`),
  ADD KEY `id_dosen` (`id_dosen`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dosen`
--
ALTER TABLE `dosen`
  MODIFY `id_dosen` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `fakultas`
--
ALTER TABLE `fakultas`
  MODIFY `id_fakultas` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `jurusan`
--
ALTER TABLE `jurusan`
  MODIFY `id_jurusan` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  MODIFY `id_mhs` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `matkul`
--
ALTER TABLE `matkul`
  MODIFY `id_matkul` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `nilai`
--
ALTER TABLE `nilai`
  MODIFY `id_nilai` int(3) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `dosen`
--
ALTER TABLE `dosen`
  ADD CONSTRAINT `dosen_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`);

--
-- Constraints for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD CONSTRAINT `mahasiswa_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`);

--
-- Constraints for table `matkul`
--
ALTER TABLE `matkul`
  ADD CONSTRAINT `matkul_ibfk_1` FOREIGN KEY (`id_fakultas`) REFERENCES `fakultas` (`id_fakultas`),
  ADD CONSTRAINT `matkul_ibfk_2` FOREIGN KEY (`id_jurusan`) REFERENCES `jurusan` (`id_jurusan`),
  ADD CONSTRAINT `matkul_ibfk_3` FOREIGN KEY (`id_dosen`) REFERENCES `dosen` (`id_dosen`);

--
-- Constraints for table `nilai`
--
ALTER TABLE `nilai`
  ADD CONSTRAINT `nilai_ibfk_1` FOREIGN KEY (`id_mhs`) REFERENCES `mahasiswa` (`id_mhs`),
  ADD CONSTRAINT `nilai_ibfk_2` FOREIGN KEY (`id_fakultas`) REFERENCES `fakultas` (`id_fakultas`),
  ADD CONSTRAINT `nilai_ibfk_3` FOREIGN KEY (`id_jurusan`) REFERENCES `jurusan` (`id_jurusan`),
  ADD CONSTRAINT `nilai_ibfk_4` FOREIGN KEY (`id_matkul`) REFERENCES `matkul` (`id_matkul`),
  ADD CONSTRAINT `nilai_ibfk_5` FOREIGN KEY (`id_dosen`) REFERENCES `dosen` (`id_dosen`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
