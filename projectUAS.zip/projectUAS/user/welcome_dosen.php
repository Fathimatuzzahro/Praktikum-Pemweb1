<!doctype html>
<html lang="en" id="home">
<head>
    <meta charset="UTF-8">
    <title>Home | Dosen</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <style>
        body{ font: 14px sans-serif; text-align: center; }
    </style>
    
</head>
<body>
    <!-- navbar -->
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <!-- dalam button ada data target yang harus sama dengan id menu pada navbarnya -->
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="#home" class="navbar-brand page-scroll">Sistem Informasi Akademik</a>
            </div>

            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <a href="logout.php" class="btn btn-danger ml-3">Logout</a>                  
                </ul>
            </div>
        </div>
    </nav>
    <!-- akhir navbar -->

    <!-- jumbotron -->
    <div class="jumbotron text-center">
        <!-- <img src="img/wpp.jpg" class="img-square"> -->
        <h1>Selamat Datang</h1>     
    </div>

    <br>
    </br>

    <!-- cc 1 -->
    <div class="container">
        <div class="row">
            <div class=".col-md-3 .col-md-offset-3">
                <div class="thumbnail">
                <img src="img/user.png" alt="...">
                    <div class="caption">
                        <h3>Data Mahasiswa</h3>
                        <p>Daftar Data Mahasiswa</p>
                        <p><a href="#" class="btn btn-primary" role="button">Selengkapnya</a>
                    </div>
                </div>
            </div>
        </div>    
    </div>
    <!-- akhir cc 1 -->

    <br>
    </br>

    <!-- cc 2 -->
    <div class="container">
        <div class="row">
            <div class=".col-md-3 .col-md-offset-3">
                <div class="thumbnail">
                <img src="img/clipboard.png" alt="...">
                    <div class="caption">
                        <h3>Data Mata Kuliah</h3>
                        <p>Daftar Mata Kuliah</p>
                        <p><a href="#" class="btn btn-primary" role="button">Selengkapnya</a>
                    </div>
                </div>
            </div>
        </div>    
    </div>
    <!-- akhir c 2 -->

    <br>
    </br>
    
    <!-- cc 3 -->
    <div class="container">
        <div class="row">
            <div class=".col-md-3 .col-md-offset-3">
                <div class="thumbnail">
                <img src="img/grade3.png" alt="...">
                    <div class="caption">
                        <h3>Nilai Mahasiswa</h3>
                        <p>Isi Nilai Mahasiswa</p>
                        <p><a href="#" class="btn btn-primary" role="button">Selengkapnya</a>
                    </div>
                </div>
            </div>
        </div>    
    </div>
    <!-- akhir cc 3 -->
    <p>
        <h2></h2>
   
</body>

</html>